# backend/users/serializers.py
from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Student, Teacher, Institution
from api.models import Course, Enrollment  # <-- IMPORTANT

class RegisterWithStudentIDSerializer(serializers.ModelSerializer):
    student_id = serializers.CharField(write_only=True)
    course = serializers.CharField(write_only=True, required=False, allow_blank=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password', 'student_id', 'course')
        extra_kwargs = {'password': {'write_only': True}}

    def validate_student_id(self, value):
        try:
            student = Student.objects.get(student_id=value)
        except Student.DoesNotExist:
            raise serializers.ValidationError("Invalid student ID.")
        if student.user:
            raise serializers.ValidationError("This student ID is already linked to a user.")
        return value

    def create(self, validated_data):
        student_id = validated_data.pop('student_id')
        course_name = validated_data.pop('course', None)
        password = validated_data.pop('password')
        user = User.objects.create_user(password=password, **validated_data)

        student = Student.objects.get(student_id=student_id)
        student.user = user
        student.save()

        if course_name:
            try:
                course = Course.objects.get(title=course_name)
                Enrollment.objects.get_or_create(student=student, course=course)
            except Course.DoesNotExist:
                # Silently ignore if course title doesn't exist
                pass

        return user

class UserProfileSerializer(serializers.Serializer):
    username = serializers.CharField()
    email = serializers.EmailField()
    role = serializers.CharField()

    def to_representation(self, instance):
        user = instance
        role = 'student'
        if hasattr(user, 'teacher'):
            role = 'teacher'
        elif hasattr(user, 'institution'):
            role = 'institution'
        elif hasattr(user, 'student'):
            role = 'student'
        return {
            'username': user.username,
            'email': user.email,
            'role': role,
        }

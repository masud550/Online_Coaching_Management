# backend/users/admin.py
from django.contrib import admin
from .models import Student, Teacher, Institution

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('get_username', 'get_email', 'student_id', 'full_name', 'age', 'education')
    search_fields = ('user__username', 'user__email', 'student_id', 'full_name')
    list_editable = ('student_id', 'age', 'education')

    def get_username(self, obj):
        return obj.user.username if obj.user else "(no user)"
    get_username.short_description = 'Username'

    def get_email(self, obj):
        return obj.user.email if obj.user else "(no user)"
    get_email.short_description = 'Email'

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ('get_username', 'get_email', 'subject', 'institution')
    search_fields = ('user__username', 'user__email', 'subject')

    def get_username(self, obj):
        return obj.user.username
    get_username.short_description = 'Username'

    def get_email(self, obj):
        return obj.user.email
    get_email.short_description = 'Email'

@admin.register(Institution)
class InstitutionAdmin(admin.ModelAdmin):
    list_display = ('get_username', 'get_email', 'name')
    search_fields = ('user__username', 'user__email', 'name')

    def get_username(self, obj):
        return obj.user.username
    get_username.short_description = 'Username'

    def get_email(self, obj):
        return obj.user.email
    get_email.short_description = 'Email'

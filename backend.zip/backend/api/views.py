# backend/api/views.py
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import ValidationError
from .models import Course, CourseVideo, Service, StudentStory, Contact, Enrollment
from .serializers import (
    CourseSerializer, CourseVideoSerializer, ServiceSerializer,
    StudentStorySerializer, ContactSerializer, EnrollmentSerializer
)
from users.models import Student

class EnrollmentCreateView(generics.CreateAPIView):
    queryset = Enrollment.objects.all()
    serializer_class = EnrollmentSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        try:
            student = Student.objects.get(user=user)
        except Student.DoesNotExist:
            raise ValidationError("Only students can enroll in courses.")
        serializer.save(student=student)

class CourseListView(generics.ListAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer

class CourseVideoListView(generics.ListAPIView):
    serializer_class = CourseVideoSerializer
    def get_queryset(self):
        course_id = self.kwargs['course_id']
        return CourseVideo.objects.filter(course_id=course_id)

class ServiceListView(generics.ListAPIView):
    queryset = Service.objects.all()
    serializer_class = ServiceSerializer

class StudentStoryListView(generics.ListAPIView):
    queryset = StudentStory.objects.all()
    serializer_class = StudentStorySerializer

class ContactCreateView(generics.CreateAPIView):
    queryset = Contact.objects.all()
    serializer_class = ContactSerializer

class StudentDashboardView(generics.ListAPIView):
    serializer_class = EnrollmentSerializer
    permission_classes = [IsAuthenticated]
    def get_queryset(self):
        user = self.request.user
        try:
            student = Student.objects.get(user=user)
        except Student.DoesNotExist:
            return Enrollment.objects.none()
        return Enrollment.objects.filter(student=student)

# backend/api/admin.py
from django.contrib import admin
from .models import Contact, Course, CourseVideo, Enrollment

# -----------------------------
# Contact Admin
# -----------------------------
@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'message', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('name', 'email', 'phone', 'message')


# -----------------------------
# Course & CourseVideo Admin
# -----------------------------
class CourseVideoInline(admin.TabularInline):
    model = CourseVideo
    extra = 0

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'teacher', 'institution', 'created_at')  # removed fee (not in model)
    search_fields = ('title',)
    inlines = [CourseVideoInline]


@admin.register(CourseVideo)
class CourseVideoAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'course', 'order')
    list_filter = ('course',)


# -----------------------------
# Enrollment Admin
# -----------------------------
@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'student', 'course', 'enrolled_at')
    list_filter = ('course',)

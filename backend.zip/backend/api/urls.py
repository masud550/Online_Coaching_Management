# backend/api/urls.py
from django.urls import path
from .views import (
    CourseListView, CourseVideoListView, StudentDashboardView,
    ServiceListView, StudentStoryListView, ContactCreateView, EnrollmentCreateView
)
from users.views import MeView

urlpatterns = [
    path("courses/", CourseListView.as_view(), name="course-list"),
    path("courses/<int:course_id>/videos/", CourseVideoListView.as_view(), name="course-videos"),
    path("dashboard/student/", StudentDashboardView.as_view(), name="student-dashboard"),
    path("services/", ServiceListView.as_view(), name="services"),
    path("stories/", StudentStoryListView.as_view(), name="student-stories"),
    path("contact/", ContactCreateView.as_view(), name="contact"),
    path("enroll/", EnrollmentCreateView.as_view(), name="enroll"),  # authenticated enroll
    path("me/", MeView.as_view(), name="me"),
]

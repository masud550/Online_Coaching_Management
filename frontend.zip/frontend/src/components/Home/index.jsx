import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/autoplay';
import { Autoplay } from 'swiper/modules';
import './style.css';
import { FaFacebookF, FaLinkedinIn, FaYoutube, FaTwitter, FaInstagram, FaPinterestP } from 'react-icons/fa';
import { SiTiktok } from 'react-icons/si';
import Footer from '../Commontext/Footer';
import { Link } from 'react-router-dom';
const Home = () => {
  return (
    <div>

      {/* ========================= Moving Headline ========================= */}
      <div className="overflow-hidden py-2 mb-4">
        <div className="animate-marquee text-green-800 text-2xl">
          🎓 Welcome to BUSINESS SCHOOL IT – Empowering your future through smart learning!
        </div>
      </div>

      {/* ========================= Motivation + Banner Section ========================= */}
      <div className="flex flex-col md:flex-row justify-center items-center px-4 md:px-20 gap-6">
        <div className="md:w-1/2 text-center md:text-left space-y-4">
          <h2 className="text-3xl font-bold text-red-500">Learn Bangladesh</h2>
          <p className="text-gray-700">
            Start your learning journey now! Explore our courses and build your skills.
            BUSINESS SCHOOL IT is a modern online learning platform for Digital Marketing, English Communication, and Freelancing. Our courses are available online and offline through live classes, flexible timing, and expert instructors. A certificate is provided upon successful course completion.
          </p>
        </div>

        <div className="md:w-1/2 w-full">
          <Swiper
            modules={[Autoplay]}
            spaceBetween={30}
            autoplay={{ delay: 3000 }}
            loop={true}
          >
            <SwiperSlide>
              <img src="/images/banner1.png" alt="Banner 1" className="rounded-xl w-full" />
            </SwiperSlide>
            <SwiperSlide>
              <img src="/images/banner2.png" alt="Banner 2" className="rounded-xl w-full" />
            </SwiperSlide>
          </Swiper>
        </div>
      </div>

      {/* ========================= Student Services ========================= */}
      <div className="bg-white py-12 px-4 md:px-20">
        <h2 className="text-3xl md:text-2xl font-bold text-center mb-2">
          <span className="text-red-500">Student Services</span>
        </h2>
        <p className="text-center text-gray-600 mb-8">
          It is our responsibility to teach you practically and hands-on.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <div className="service-card">
            <img src="/images/liveclass.png" alt="Live Class" className="w-20 h-20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-500 mb-2">Live Classes</h3>
          </div>

          <div className="service-card">
            <img src="/images/support24.png" alt="24/7 Support" className="w-20 h-20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-500 mb-2">24/7 Support</h3>
          </div>

          <div className="service-card">
            <img src="/images/zoom_support.png" alt="Zoom Support" className="w-20 h-20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-500 mb-2">Backup Zoom Support</h3>
          </div>

          <div className="service-card">
            <img src="/images/team.png" alt="Dedicated Team" className="w-20 h-20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-500 mb-2">Dedicated Team</h3>
          </div>

          <div className="service-card">
            <img src="/images/recorded.png" alt="Recorded Videos" className="w-20 h-20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-500 mb-2">Recorded Classes</h3>
          </div>

          <div className="service-card">
            <img src="/images/buyer.png" alt="Marketplace Buyer" className="w-20 h-20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-500 mb-2">Buyers Outside Marketplace</h3>
          </div>
        </div>
      </div>

      {/* ========================= Our Courses ========================= */}
      <div className="py-12 px-4 md:px-20">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-6">
          <span className="text-red-500">Our Courses</span>
        </h2>
        <p className="text-center text-gray-600 mb-10">
          Discover our most popular courses.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {/* Digital Marketing */}
          <div className="animated-card bg-white rounded-xl shadow-md overflow-hidden">
            <img src="/images/digital-marketing.jpg" alt="Digital Marketing" className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-bold text-green-600 mb-2">Digital Marketing</h3>
              <p className="text-gray-700 text-sm mb-4">Master Facebook ads, SEO, email marketing, and marketing strategy.</p>
              <div className="price-badge">Course fee: 4,000</div>
              <p className="text-gray-600 text-sm text-center mt-2">30+ students enrolled</p>
            </div>
          </div>

          {/* Spoken English */}
          <div className="animated-card bg-white rounded-xl shadow-md overflow-hidden">
            <img src="/images/spoken.jpg" alt="Spoken English" className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-bold text-green-600 mb-2">Spoken English</h3>
              <p className="text-gray-700 text-sm mb-4">Improve your fluency, pronunciation, and real-life conversation skills.</p>
              <div className="price-badge">Course fee: 2,000</div>
              <p className="text-gray-600 text-sm text-center mt-2">70+ students enrolled</p>
            </div>
          </div>

          {/* Freelancing */}
          <div className="animated-card bg-white rounded-xl shadow-md overflow-hidden">
            <img src="/images/freelancing.jpg" alt="Freelancing" className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-bold text-green-600 mb-2">Freelancing</h3>
              <p className="text-gray-700 text-sm mb-4">Learn Fiverr, Upwork, and build skills to start your online career.</p>
              <div className="price-badge">Course fee: 3,000</div>
              <p className="text-gray-600 text-sm text-center mt-2">60+ students enrolled</p>
            </div>
          </div>

          {/* Web Development */}
          <div className="animated-card bg-white rounded-xl shadow-md overflow-hidden">
            <img src="/images/web-dev.jpg" alt="Web Development" className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-bold text-green-600 mb-2">Web Development</h3>
              <p className="text-gray-700 text-sm mb-4">Learn HTML, CSS, JavaScript, React, Node.js, and more.</p>
              <div className="price-badge">Course fee: 5,000</div>
              <p className="text-gray-600 text-sm text-center mt-2">50+ students enrolled</p>
            </div>
          </div>

          {/* Graphic Design */}
          <div className="animated-card bg-white rounded-xl shadow-md overflow-hidden">
            <img src="/images/graphics.jpg" alt="Graphic Design" className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-bold text-green-600 mb-2">Graphic Design</h3>
              <p className="text-gray-700 text-sm mb-4">Learn Photoshop, Illustrator, logo, poster and branding designs.</p>
              <div className="price-badge">Course fee: 3,500</div>
              <p className="text-gray-600 text-sm text-center mt-2">40+ students enrolled</p>
            </div>
          </div>

          {/* Video Editing */}
          <div className="animated-card bg-white rounded-xl shadow-md overflow-hidden">
            <img src="/images/video-editing.jpg" alt="Video Editing" className="w-full h-48 object-cover" />
            <div className="p-6">
              <h3 className="text-xl font-bold text-green-600 mb-2">Video Editing</h3>
              <p className="text-gray-700 text-sm mb-4">Learn Premiere Pro, After Effects, and create professional videos.</p>
              <div className="price-badge">Course fee: 4,000</div>
              <p className="text-gray-600 text-sm text-center mt-2">25+ students enrolled</p>
            </div>
          </div>
        </div>

        {/* See All Courses Button */}
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '2rem' }}>
          <Link to="/courses" className="animated-border-btn text-xl">
            See All Courses →
          </Link>
        </div>
      </div>
      {/* ========================= Our Marketplace ========================= */}
      <div className="bg-white py-12 px-4 md:px-20">
        <h2 className="text-2xl md:text-4xl font-bold text-center mb-6">
          <span className="text-red-600">Our Marketplace</span>
        </h2>
        <p className="text-center text-gray-600 mb-10">Learn how to succeed on top freelancing platforms.</p>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6 justify-items-center">
          <div className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
            <img src="/images/fiverr.png" alt="Fiverr" className="w-16 h-16 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-green-600">Fiverr</h3>
          </div>
          <div className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
            <img src="/images/upwork.png" alt="Upwork" className="w-16 h-16 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-green-600">Upwork</h3>
          </div>
          <div className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
            <img src="/images/freelancer.png" alt="Freelancer" className="w-16 h-16 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-green-600">Freelancer</h3>
          </div>
          <div className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
            <img src="/images/pph.png" alt="PeoplePerHour" className="w-16 h-16 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-green-600">PeoplePerHour</h3>
          </div>
          <div className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition">
            <img src="/images/indeed.png" alt="Indeed" className="w-16 h-16 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-green-600">Indeed</h3>
          </div>
        </div>
      </div>

      {/* ========================= Student Success ========================= */}
      <div className="bg-white py-16 px-4 md:px-20">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-3xl font-bold text-red-600 mb-4">
            Business School IT Student Success
          </h2>
          <p className="text-xl text-gray-600">Your Success is Our Pride</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <div className="bg-gradient-to-br from-orange-100 to-yellow-50 rounded-xl p-6 shadow-md text-center hover:shadow-xl transition">
            <div className="text-5xl font-bold text-orange-600 mb-3">5000+</div>
            <h3 className="text-xl font-semibold text-gray-800">Total Students</h3>
          </div>
          <div className="bg-gradient-to-br from-orange-100 to-yellow-50 rounded-xl p-6 shadow-md text-center hover:shadow-xl transition">
            <div className="text-5xl font-bold text-orange-600 mb-3">3000+</div>
            <h3 className="text-xl font-semibold text-gray-800">Successful Students</h3>
          </div>
          <div className="bg-gradient-to-br from-orange-100 to-yellow-50 rounded-xl p-6 shadow-md text-center hover:shadow-xl transition">
            <div className="text-5xl font-bold text-orange-600 mb-3">5+</div>
            <h3 className="text-xl font-semibold text-gray-800">Years of Success</h3>
          </div>
        </div>
      </div>
      {/* ========================= Footer ========================= */}
      <Footer />
    </div>
  );
};

export default Home;

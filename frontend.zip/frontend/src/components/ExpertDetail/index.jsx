import React from "react";
import { useParams } from "react-router-dom";
import { FaFacebook, FaLinkedin, FaTwitter } from "react-icons/fa";

const expertiseData = [
  { 
    id: 1, 
    name: "Abu Bakar Chowdhury", 
    position: "Senior Instructor - Digital Marketing", 
    image: "/images/expertise1.jpg",
    qualification: "BSc in Textile Engineering",
    expertise: ["Digital Marketing Strategy", "SEO", "Google Ads"],
    portfolio: [
      { title: "SEO Project", description: "Optimized websites with 200% organic growth", link: "#" }
    ],
    social: { facebook: "https://facebook.com", linkedin: "https://linkedin.com", twitter: "https://twitter.com" }
  },
  { 
    id: 2, 
    name: "Sarah Wilson", 
    position: "Instructor - Spoken English", 
    image: "/images/expertise2.jpg",
    qualification: "MA in English Literature",
    expertise: ["Public Speaking", "Business Communication"],
    portfolio: [
      { title: "Corporate Training", description: "Trained 500+ professionals in spoken English", link: "#" }
    ],
    social: { facebook: "https://facebook.com", linkedin: "https://linkedin.com", twitter: "https://twitter.com" }
  },
  { 
    id: 3, 
    name: "Robert Johnson", 
    position: "Instructor - Freelancing", 
    image: "/images/expertise3.jpg",
    qualification: "BSc in Computer Science",
    expertise: ["Freelance Platforms", "Client Management", "Upwork / Fiverr"],
    portfolio: [
      { title: "Freelancing Workshop", description: "Helped 300+ students start freelancing careers", link: "#" }
    ],
    social: { facebook: "https://facebook.com", linkedin: "https://linkedin.com", twitter: "https://twitter.com" }
  },
  { 
    id: 4, 
    name: "Emily Davis", 
    position: "Instructor - Web Development", 
    image: "/images/expertise4.jpg",
    qualification: "BSc in Software Engineering",
    expertise: ["Full Stack Development", "React & Django", "REST APIs"],
    portfolio: [
      { title: "E-commerce Website", description: "Built a scalable MERN e-commerce app", link: "#" }
    ],
    social: { facebook: "https://facebook.com", linkedin: "https://linkedin.com", twitter: "https://twitter.com" }
  },
  { 
    id: 5, 
    name: "Michael Brown", 
    position: "Instructor - Graphic Design", 
    image: "/images/expertise5.jpg",
    qualification: "Diploma in Graphic Design",
    expertise: ["Adobe Photoshop", "Illustrator", "UI/UX Design"],
    portfolio: [
      { title: "Brand Design", description: "Created logos and branding kits for startups", link: "#" }
    ],
    social: { facebook: "https://facebook.com", linkedin: "https://linkedin.com", twitter: "https://twitter.com" }
  },
  { 
    id: 6, 
    name: "David Lee", 
    position: "Instructor - Video Editing", 
    image: "/images/expertise6.jpg",
    qualification: "BSc in Multimedia & Animation",
    expertise: ["Premiere Pro", "After Effects", "Video Storytelling"],
    portfolio: [
      { title: "YouTube Content Editing", description: "Edited 100+ professional YouTube videos", link: "#" }
    ],
    social: { facebook: "https://facebook.com", linkedin: "https://linkedin.com", twitter: "https://twitter.com" }
  },
];

const ExpertDetail = () => {
  const { id } = useParams();
  const expert = expertiseData.find((exp) => exp.id === parseInt(id));

  if (!expert) {
    return <div className="p-6 text-center text-red-500">Expert not found</div>;
  }

  return (
    <div className="p-8 md:px-20">
      {/* Profile Section */}
      <div className="flex flex-col items-center">
        <img src={expert.image} alt={expert.name} className="w-40 h-40 rounded-full border-4 border-green-500 mb-4" />
        <h2 className="text-3xl font-bold">{expert.name}</h2>
        <p className="text-gray-600">{expert.position}</p>
      </div>

      {/* Expertise + Qualification */}
      <div className="grid md:grid-cols-2 gap-6 mt-10">
        <div className="p-6 border rounded-lg shadow-sm">
          <h3 className="font-semibold text-lg mb-2">Expertise</h3>
          <ul className="list-disc pl-5 text-gray-700">
            {expert.expertise.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>

        <div className="p-6 bg-white border rounded-lg shadow-sm">
          <h3 className="font-semibold text-lg mb-2">Qualification</h3>
          <p>{expert.qualification}</p>
          <div className="flex gap-6 mt-4 text-2xl">
            <a href={expert.social.facebook} target="_blank" rel="noreferrer" className="text-blue-600 hover:text-blue-800">
              <FaFacebook />
            </a>
            <a href={expert.social.linkedin} target="_blank" rel="noreferrer" className="text-blue-700 hover:text-blue-900">
              <FaLinkedin />
            </a>
            <a href={expert.social.twitter} target="_blank" rel="noreferrer" className="text-sky-500 hover:text-sky-700">
              <FaTwitter />
            </a>
          </div>
        </div>
      </div>

      {/* Portfolio Section */}
      <div className="mt-10">
        <h3 className="text-2xl font-bold mb-4">Portfolio</h3>
        <div className="grid md:grid-cols-2 gap-6">
          {expert.portfolio.map((project, index) => (
            <div key={index} className="p-6 border rounded-lg shadow-md hover:shadow-lg">
              <h4 className="font-semibold">{project.title}</h4>
              <p className="text-gray-600">{project.description}</p>
              {project.link && (
                <a href={project.link} target="_blank" rel="noreferrer" className="text-green-600 underline mt-2 inline-block">
                  View Project
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExpertDetail;

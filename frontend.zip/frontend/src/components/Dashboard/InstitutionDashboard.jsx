//C:\Projects\online_coaching_management\frontend\src\components\Dashboard\InstitutionDashboard.jsx
import React from 'react';

const InstitutionDashboard = () => (
  <div style={{ padding: 24 }}>
    <h2>Institution Dashboard</h2>
    <p>Welcome institution! Your programs and analytics will appear here.</p>
  </div>
);
export default InstitutionDashboard;

//C:\Projects\online_coaching_management\frontend\src\components\Dashboard\TeacherDashboard.jsx
import React from 'react';

const TeacherDashboard = () => (
  <div style={{ padding: 24 }}>
    <h2>Teacher Dashboard</h2>
    <p>Welcome teacher! Your classes and students will appear here.</p>
  </div>
);
export default TeacherDashboard;

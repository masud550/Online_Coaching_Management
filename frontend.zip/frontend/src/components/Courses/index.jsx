// src/components/Courses/index.jsx
import React, { useState } from "react";
import "./style.css";
import Footer from "../Commontext/Footer";

const API_BASE = process.env.REACT_APP_API_BASE_URL;

// ========================= Courses Data =========================
const coursesData = [
  { id: 1, title: "Digital Marketing", description: "Master Facebook ads, SEO, email marketing, and marketing strategy.", fee: 4000, image: "/images/digital-marketing.jpg" },
  { id: 2, title: "Spoken English", description: "Improve your fluency, pronunciation, and real-life conversation skills.", fee: 2000, image: "/images/spoken.jpg" },
  { id: 3, title: "Freelancing", description: "Learn Fiverr, Upwork, and build skills to start your online career.", fee: 3000, image: "/images/freelancing.jpg" },
  { id: 4, title: "Web Development", description: "Learn HTML, CSS, JavaScript, React, Node.js, and more.", fee: 5000, image: "/images/web-dev.jpg" },
  { id: 5, title: "Graphic Design", description: "Learn Photoshop, Illustrator, logo, poster and branding designs.", fee: 3500, image: "/images/graphics.jpg" },
  { id: 6, title: "Video Editing", description: "Learn video editing, motion graphics, and create stunning content.", fee: 2500, image: "/images/video-editing.jpg" }
];

// ========================= Benefits Data =========================
const benefitsData = [
  "You will get around 40 hours of online Zoom classes in each course.",
  "Every month there are special live Q&A and tips classes outside of the course.",
  "To ensure learning, we provide 1:1 support via Messenger/Telegram/Zoom.",
  "24/7 lifetime support group is available.",
  "You will get the opportunity to do group work and team projects.",
  "After each class, the recorded video will be provided so that you can watch it anytime.",
  "You will get a certificate after completing the course, which you can use for freelancing platforms or professional jobs.",
  "We will guide you on freelancing marketplaces and job opportunities abroad.",
  "From us, you will get lifetime support."
];

// ========================= Courses Component =========================
const Courses = () => {
  // ===== States =====
  const [showModal, setShowModal] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);

  const [studentId, setStudentId] = useState("");
  const [fullName, setFullName] = useState("");
  const [age, setAge] = useState("");
  const [education, setEducation] = useState("");
  const [feedback, setFeedback] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // ===== Handlers =====
  const openEnroll = (course) => {
    setSelectedCourse(course);
    setStudentId("");
    setFullName("");
    setAge("");
    setEducation("");
    setFeedback("");
    setShowModal(true);
  };

  const submitEnrollment = async () => {
    if (!studentId || !fullName || !age || !education) {
      setFeedback("⚠️ Please fill all fields before submitting.");
      return;
    }
    setSubmitting(true);
    setFeedback("");

    try {
      const res = await fetch(`${API_BASE}/users/enroll/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          student_id: studentId.trim(),
          name: fullName.trim(),
          age,
          education: education.trim(),
          course_id: selectedCourse.id,  // course auto-filled
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Enrollment failed");

      setFeedback("✅ Enrollment successful! Now Sign Up using the same Student ID.");
    } catch (err) {
      setFeedback(`❌ ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="courses-page">

      {/* ========================= Header Section ========================= */}
      <div className="courses-header px-4 md:px-20 py-12 text-center">
        <p className="text-red-600 font-bold mb-10 text-3xl">Explore our popular courses and enroll now!</p>
      </div>

      {/* ========================= Courses Grid ========================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6 px-4 md:px-20">
        {coursesData.map((course) => (
          <div key={course.id} className="animated-card bg-white rounded-xl shadow-md overflow-hidden">
            <img src={course.image} alt={course.title} className="w-full h-48 object-cover" />
            <div className="p-6 text-center">
              <h3 className="text-xl font-bold text-green-600 mb-2">{course.title}</h3>
              <p className="text-gray-700 text-sm mb-4">{course.description}</p>
              <div className="price-badge mb-3">Course Fee: {course.fee} BDT</div>
              <button className="animated-border-btn" onClick={() => openEnroll(course)}>
                Enroll Now
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ========================= Benefits Section ========================= */}
      <div className="benefits-section flex flex-col md:flex-row items-center gap-10 px-4 md:px-20 py-16">
        {/* Left Text Side */}
        <div className="flex-1">
          <h2 className="text-3xl font-bold mb-4 text-center md:text-left">
            Benefits of Doing Our Courses
          </h2>
          <p className="text-gray-600 mb-6 text-center md:text-left">
            Expert IT Park will make you a skilled freelancer.
          </p>
          <ul className="space-y-3 text-gray-700">
            {benefitsData.map((benefit, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-green-600 mt-1">▶</span>
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        </div>
        {/* Right Image Side */}
        <div className="flex-1 flex justify-center">
          <img
            src="/images/benefits-illustration.png"
            alt="Course Benefits"
            className="max-w-sm"
          />
        </div>
      </div>
      {/* ========================= Why Choose + Video Section ========================= */}
      <div className="why-choose-section px-4 md:px-20 py-12">
        <div className="why-choose-container">
          {/* Left Text */}
          <div className="why-choose-text">
            <h2>Why <span>Choose Us</span>?</h2>
            <p>
              We are dedicated to providing high-quality courses that prepare students
              for the real-world freelancing and job market. With expert mentors,
              live classes, recorded lessons, and 24/7 support, we ensure that you
              gain the skills needed to build your career successfully.
            </p>
            <ul>
              <li>Professional instructors with real industry experience.</li>
              <li>Hands-on projects and assignments.</li>
              <li>Interactive live classes and Q&A sessions.</li>
              <li>Lifetime access to learning materials and community.</li>
            </ul>
          </div>

          {/* Right Video */}
          <div className="why-choose-video">
            <iframe
              width="100%"
              height="315"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              title="Intro Video"
              frameBorder="0"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>

      {/* ========================= Admission Section (with Transaction Options) ========================= */}
      <div className="admission-section px-4 md:px-20 py-16 bg-white">
        <h2 className="text-3xl font-bold mb-4 text-center text-red-600">
          What You Need To Do For Admission
        </h2>
        <p className="text-center text-gray-700 mb-10">Admission Guidelines</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
          {/* Left Side: Video */}
          <div className="admission-video flex justify-center">
            <iframe
              width="100%"
              height="315"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ"
              title="Admission Video"
              frameBorder="0"
              allowFullScreen
              className="rounded-lg shadow-lg"
            ></iframe>
          </div>

          {/* Right Side: Admission Details */}
          <div className="admission-text text-gray-800 space-y-4 leading-relaxed">
            <p>
              The course fee starts from <span className="font-semibold">2000 BDT</span>.
              On the first day of admission, you must pay an initial
              <span className="font-semibold"> 500 BDT admission fee</span>.
            </p>
            <p>
              If you want to make a <span className="font-semibold text-red-600">full payment at once</span>,
              you will get a <span className="font-semibold">special discount</span>.
            </p>
            <p>
              Once the payment is completed, you will be added to our official support group
              <span className="font-semibold"> “Freelancer Faruk Help Group”</span> where you will get
              course updates, resources, and direct help.
            </p>
            <p className="font-bold text-red-600">
              Without admission, you will not be able to attend the classes.
            </p>
            <p>
              For more details, contact us on our official Facebook page:
              <span className="text-green-600">  BUSINESS SCHOOL IT</span>
            </p>
          </div>
        </div>
        {/* Course Details Section */}
        <section className="course-details">
          <div className="container">
            <h2 className="course-title">This Course Includes</h2>
            <p className="course-subtitle">Classes will be provided sequentially.</p>

            <div className="course-grid">
              {/* Course Module */}
              <div className="course-column">
                <h3>Course Module</h3>
                <h4>Social Media Marketing (SMM)</h4>
                <ul>
                  <li>Facebook Profile, Page</li>
                  <li>Group Create and Optimization</li>
                  <li>Facebook Professional Post</li>
                  <li>Facebook Meta Business Suite</li>
                  <li>Facebook Marketing</li>
                  <li>Facebook Page Monetization</li>
                  <li>Facebook Boost and Promote</li>
                  <li>Create Dual Currency Card</li>
                  <li>Content Marketing</li>
                  <li>Facebook Ads Campaign for Awareness</li>
                  <li>Facebook Ads Funnel & Strategy</li>
                  <li>Campaigns for Engagement, Leads, Traffic, Sales</li>
                  <li>Create a Free Website for Practice Pixel</li>
                  <li>Facebook Pixel Setup & Conversion API</li>
                  <li>Instagram Marketing</li>
                  <li>Twitter/X Marketing</li>
                  <li>Twitter/X Ads Campaign</li>
                  <li>LinkedIn Profile, Page, Group Setup</li>
                  <li>LinkedIn Ads Campaign</li>
                  <li>LinkedIn Job Apply / Remote Job</li>
                  <li>Social Media Marketing Advance Tools</li>
                </ul>
              </div>

              {/* Bonus Class */}
              <div className="course-column">
                <h3>Bonus Class</h3>
                <h4>YouTube Master Class</h4>
                <ul>
                  <li>YouTube Channel Create & Setup Professionally</li>
                  <li>Move Brand Channel</li>
                  <li>Everything About YouTube Channel</li>
                  <li>Professional Video Upload</li>
                  <li>Create Title & Description SEO Friendly</li>
                  <li>How to use VidIQ & Tubebuddy with Advanced SEO Tools</li>
                  <li>Buyer Video SEO using VidIQ & Tubebuddy Extensions</li>
                  <li>Channel Audit and SEO</li>
                </ul>
              </div>

              {/* Marketplace Class */}
              <div className="course-column">
                <h3>Marketplace Class</h3>
                <ul>
                  <li>Professional Fiverr Account Create & Setup</li>
                  <li>Fiverr Profile Setup (All Settings)</li>
                  <li>Gig Title Research</li>
                  <li>Fiverr Gig Creation & SEO with Advanced Tools</li>
                  <li>Fiverr Gig Marketing</li>
                  <li>Payoneer Account Create and Verify</li>
                  <li>Payoneer Account Connect with Fiverr</li>
                  <li>Upwork Account Create & Setup</li>
                  <li>Upwork Job Bidding</li>
                  <li>Upwork Project Create</li>
                </ul>

                <h4>Search Engine Marketing (SEM)</h4>
                <ul>
                  <li>Google Search Ads / PPC Campaign</li>
                  <li>Google Ads Keyword Research</li>
                  <li>Google Display Ads Campaign</li>
                  <li>YouTube Ads Campaign</li>
                  <li>Google Conversion Tracking (using GTM)</li>
                  <li>Google Analytics</li>
                  <li>Google Ads Remarketing (GA4)</li>
                  <li>Google Ads Strategy</li>
                </ul>
              </div>
            </div>
          </div>
        </section>


        {/* Transaction / Payment Options (inside Admission Section) */}
        <div className="transaction-section mt-12 px-2 md:px-10">
          <h3 className="text-2xl font-bold text-center mb-6">Payment Methods</h3>
          <p className="text-center text-gray-600 mb-6">
            Please make your payment via one of the following methods and keep the transaction screenshot.
            After payment, send the transaction screenshot and your Student ID to our support number or page.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Bkash */}
            <div className="txn-card p-6 border rounded-lg shadow-sm text-center">
              <img src="/images/bkash.png" alt="Bkash" className="h-12 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-pink-600 mb-2">Bkash</h4>
              <p className="text-gray-700 mb-2">Number: <strong>017XXXXXXXX</strong></p>
              <p className="text-gray-700">Type: Personal / Merchant (specify)</p>
            </div>

            {/* Nagad */}
            <div className="txn-card p-6 border rounded-lg shadow-sm text-center">
              <img src="/images/nagad.png" alt="Nagad" className="h-12 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-orange-600 mb-2">Nagad</h4>
              <p className="text-gray-700 mb-2">Number: <strong>018XXXXXXXX</strong></p>
              <p className="text-gray-700">Type: Personal / Merchant (specify)</p>
            </div>

            {/* Bank */}
            <div className="txn-card p-6 border rounded-lg shadow-sm text-center">
              <img src="/images/bank.png" alt="Bank" className="h-12 mx-auto mb-3" />
              <h4 className="text-xl font-semibold text-blue-600 mb-2">Bank Transfer</h4>
              <p className="text-gray-700 mb-1">Account Name: <strong> BUSINESS SCHOOL IT</strong></p>
              <p className="text-gray-700 mb-1">Account No: <strong>123456789</strong></p>
              <p className="text-gray-700">Bank: Dutch-Bangla Bank, Dhaka Branch</p>
            </div>
          </div>
        </div>
      </div>

     
      {/* ========================= Enrollment Modal ========================= */}
      {showModal && selectedCourse && (
        <div className="overlay">
          <div className="enroll-modal">
            <button className="close-btn" onClick={() => setShowModal(false)}>✕</button>
            <h3 className="mb-2">Enroll: {selectedCourse.title}</h3>
            <p className="mb-3 text-sm text-gray-500">
              Fill up the form to reserve your seat. After this, please Sign Up using the same Student ID.
            </p>

            {/* Inputs */}
            <input type="text" value={studentId} onChange={(e) => setStudentId(e.target.value)} placeholder="Student ID (from admin)" />
            <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Full Name" />
            <input type="number" value={age} onChange={(e) => setAge(e.target.value)} placeholder="Age" />
            <input type="text" value={education} onChange={(e) => setEducation(e.target.value)} placeholder="Education (e.g. HSC, BSc)" />

            {/* Course auto-filled */}
            <input type="text" value={selectedCourse.title} disabled className="bg-gray-100 cursor-not-allowed" />

            {feedback && <p className="feedback" style={{ marginTop: 12 }}>{feedback}</p>}

            <button className="submit-btn" onClick={submitEnrollment} disabled={submitting}>
              {submitting ? "Submitting..." : "Submit Enrollment"}
            </button>

            <div className="mt-4 text-sm text-gray-600">
              After successful enrollment, go to <strong>Sign Up</strong> and enter the same Student ID.
            </div>
          </div>
        </div>
      )}

      {/* ========================= Footer ========================= */}
      <Footer />
    </div>
  );
};

export default Courses;

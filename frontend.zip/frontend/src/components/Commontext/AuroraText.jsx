import React from 'react';
import './aurora.css'; // Import the effect styles

const AuroraText = () => {
  return (
    <span className="aurora-text">
      BUSINESS <span>SCHOOL</span> <span>IT</span>
    </span>
  );
};

export default AuroraText;

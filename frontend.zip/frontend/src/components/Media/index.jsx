import React from "react";
import { mediaPersonsData } from "./data";
import Footer from "../Commontext/Footer";
import "./style.css";

const Media = () => {
  return (
    <div>
      <div className="media-section px-4 md:px-20 py-12 bg-gray-50">
        
        {/* Section Heading */}
        <div className="text-center mb-10">
          <p className="text-purple-600 text-3xl font-semibold">
            Meet Our Media Team
          </p>
          <p className="text-gray-600 mt-2">
            These are the creative people behind our videos, photos, and promotional content.
          </p>
        </div>

        {/* Grid of Media Persons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {mediaPersonsData.map((person) => (
            <div
              key={person.id}
              className="media-card bg-white rounded-xl shadow-md p-6 text-center hover:shadow-xl transition"
            >
              <div className="mb-4">
                <img
                  src={person.image}
                  alt={person.name}
                  className="w-28 h-28 rounded-full mx-auto object-cover border-4 border-purple-500"
                />
              </div>
              <h3 className="text-lg font-bold text-purple-600">{person.name}</h3>
              <p className="text-gray-500 text-sm mb-2">{person.role}</p>
              <p className="text-gray-700 text-sm">{person.bio}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Media;

// src/components/SuccessStory/data.js
export const successStoriesData = [
  {
    id: 1,
    name: "Tanbir Ahmed",
    course: "Digital Marketing",
    image: "/images/student1.jpg",
    story: "I increased my freelance income by 3x after completing the Digital Marketing course."
  },
  {
    id: 2,
    name: "Tanisha Rahman",
    course: "Web Development",
    image: "/images/student2.jpg",
    story: "Building websites for clients became easy. Got my first 5 projects within a month!"
  },
  {
    id: 3,
    name: "Rafiq Hasan",
    course: "Freelancing",
    image: "/images/student3.jpg",
    story: "I learned Fiverr & Upwork strategies. Now I earn consistently online."
  },
  {
    id: 4,
    name: "Sadia Karim",
    course: "Graphic Design",
    image: "/images/student4.jpg",
    story: "I designed logos and banners professionally, and now I have repeat clients."
  },
  {
    id: 5,
    name: "Arif Hossain",
    course: "Video Editing",
    image: "/images/student5.jpg",
    story: "I learned Premiere Pro and After Effects. My YouTube content is now professional."
  },
];

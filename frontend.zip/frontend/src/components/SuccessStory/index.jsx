// src/components/SuccessStory/index.jsx
import React from "react";
import { successStoriesData } from "./data";
import Footer from "../Commontext/Footer";
import "./style.css";

const SuccessStory = () => {
  return (
    <div>
    <div className="success-story-section px-4 md:px-20 py-12 bg-gray-50">

      {/* Section Heading */}
      <div className="text-center mb-10">
        <p className="text-rose-600 text-3xl">
          See how our students achieved success after completing our courses
        </p>
      </div>

      {/* Grid of Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {successStoriesData.map((story) => (
          <div key={story.id} className="success-card bg-white rounded-xl shadow-md p-6 text-center hover:shadow-xl transition">
            <div className="mb-4">
              <img
                src={story.image}
                alt={story.name}
                className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-red-500"
              />
            </div>
            <h3 className="text-xl font-bold text-green-600 mb-1">{story.name}</h3>
            <p className="text-gray-500 text-sm mb-3">{story.course}</p>
            <p className="text-gray-700 text-sm">{story.story}</p>
          </div>
        ))}
      </div>
</div>
      {/* Footer */}
      <Footer />
    </div>
  );
};

export default SuccessStory;


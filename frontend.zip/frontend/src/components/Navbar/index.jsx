// C:\Projects\online_coaching_management\frontend\src\components\Navbar\index.jsx
import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import AuroraText from '../Commontext/AuroraText';
import './style.css';
import {
  FaHome,
  FaServicestack,
  FaBookOpen,
  FaEnvelope,
  FaBrain,
  FaUsers,
  FaImages,
  FaVideo,
  FaSignInAlt,
  FaSearch,
  FaBars,
  FaTimes,
  FaCalendarAlt,
} from 'react-icons/fa';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  // API Call
  const fetchSuggestions = async (searchTerm) => {
    if (!searchTerm.trim()) {
      setSuggestions([]);
      return;
    }
    try {
      setLoading(true);
      const res = await fetch(`https://dummyjson.com/products/search?q=${searchTerm}`);
      const data = await res.json();
      setSuggestions(data.products || []);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching search suggestions:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    const timeout = setTimeout(() => {
      fetchSuggestions(query);
    }, 400);
    return () => clearTimeout(timeout);
  }, [query]);

  return (
    <nav className="bg-gray-800 text-white p-4 sticky top-0 z-50 shadow-lg">
      {/* Brand + Logo */}
      <div className="text-center font-bold text-2xl mb-2">
        <NavLink to="/" className="inline-flex items-center gap-2 justify-center">
          <img src="/images/logo.jpg" alt="Brand Logo" className="w-10 h-10 object-contain" />
          <AuroraText />
        </NavLink>
      </div>

      {/* Search */}
      <div className="flex items-center justify-center gap-2 mb-4 relative">
        <div className="colorful-input-wrapper relative w-full max-w-xs">
          <input
            type="text"
            placeholder="Search..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="search-input"
          />
          {loading && <div className="absolute right-2 top-2 text-gray-500 text-sm">Loading...</div>}
          {suggestions.length > 0 && (
            <ul className="absolute left-0 right-0 bg-white text-black rounded-md mt-1 shadow-lg z-50 max-h-60 overflow-y-auto">
              {suggestions.map((item) => (
                <li
                  key={item.id}
                  className="px-3 py-2 hover:bg-gray-200 cursor-pointer"
                  onClick={() => {
                    setQuery(item.title);
                    setSuggestions([]);
                  }}
                >
                  {item.title}
                </li>
              ))}
            </ul>
          )}
        </div>
        <button className="search-button">
          <FaSearch /> Search
        </button>
      </div>

      {/* Hamburger */}
      <div className="md:hidden flex justify-end mb-2">
        <button onClick={() => setIsOpen(!isOpen)} className="text-2xl">
          {isOpen ? <FaTimes /> : <FaBars />}
        </button>
      </div>

      {/* Nav Items */}
      <div className={`${isOpen ? 'block' : 'hidden'} md:flex md:justify-center md:items-center`}>
        <div
          className="
            flex flex-col md:flex-row gap-2 md:gap-4 pb-2 md:pb-0
            w-48 ml-auto md:w-auto md:ml-0
          "
        >
          <NavLink to="/" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaHome /><span className="whitespace-nowrap">Home</span>
          </NavLink>
          <NavLink to="/expertise" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaBrain /><span className="whitespace-nowrap">Our Expertise</span>
          </NavLink>
          <NavLink to="/successstory" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaUsers /><span className="whitespace-nowrap">Success Stories</span>
          </NavLink>
          <NavLink to="/courses" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaBookOpen /><span className="whitespace-nowrap">All Courses</span>
          </NavLink>
          <NavLink to="/events" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaCalendarAlt /><span className="whitespace-nowrap">Events</span>
          </NavLink>
          <NavLink to="/Ourservices" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaServicestack /><span className="whitespace-nowrap">Our Services</span>
          </NavLink>
          <NavLink to="/media" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaVideo /><span className="whitespace-nowrap">Media</span>
          </NavLink>
          <NavLink to="/gallery" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaImages /><span className="whitespace-nowrap">Gallery</span>
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaEnvelope /><span className="whitespace-nowrap">Contact</span>
          </NavLink>
          <NavLink to="/login" className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}>
            <FaSignInAlt /><span className="whitespace-nowrap">Login</span>
          </NavLink>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

import React from 'react';
import { useParams } from 'react-router-dom';

export default function CourseDetail() {
  const { id } = useParams();
  return (
    <div style={{ padding: 24 }}>
      <h1>Course #{id}</h1>
      <p>Welcome! You were redirected here after login.</p>
    </div>
  );
}

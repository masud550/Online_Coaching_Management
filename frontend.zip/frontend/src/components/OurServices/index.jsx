//C:\Projects\online_coaching_management\frontend\src\components\Ourservices\index.jsx
import React, { useState } from "react";
import "./style.css";
import Footer from '../Commontext/Footer';
const servicesData = [
  {
    logo: "/images/seo.png",
    title: "Search Engine Optimization",
    details:
      "We perform in-depth keyword research, technical SEO audits, and on-page/off-page optimization to ensure long-term ranking improvements."
  },
  {
    logo: "/images/digital.png",
    title: "Digital Marketing",
    details:
      "We create targeted campaigns across social media, email, and search engines to maximize ROI and brand reach."
  },
  {
    logo: "/images/graphic.png",
    title: "Graphic Design",
    details:
      "We design logos, banners, social media posts, and brand kits to make your business unforgettable."
  },
  {
    logo: "/images/web.png",
    title: "Web Design",
    details:
      "We ensure your website is not only beautiful but also fast, SEO-friendly, and mobile-responsive."
  },
  {
    logo: "/images/social.png",
    title: "Social Media Marketing",
    details:
      "From content calendars to influencer collaborations, we handle all aspects of your social media growth."
  },
  {
    logo: "/images/development.png",
    title: "Website Development",
    details:
      "Our developers use modern frameworks to deliver secure, scalable, and visually stunning websites."
  }
];

const Services = () => {
  const [selectedService, setSelectedService] = useState(null);

  const handleClick = (index) => {
    setSelectedService(index);
  };

  const handleClose = () => {
    setSelectedService(null);
  };

  return (
     <>
    <div className="services-section">
      <h2 className="section-subtitle text-center">
        Services We Offer That Drive Revenue
      </h2>

      <div className="services-grid">
        {servicesData.map((service, index) => (
          <div className="services-card" key={index}>
            <img
              src={service.logo}
              alt={service.title}
              className="services-logo"
            />
            <h4
              className="service-title"
              onClick={() => handleClick(index)}
            >
              {service.title}
            </h4>
          </div>
        ))}
      </div>

      {/* Overlay Modal */}
      {selectedService !== null && (
        <div className="overlay">
          <div className="service-modal">
            <button className="close-btn" onClick={handleClose}>✕</button>
            <img
              src={servicesData[selectedService].logo}
              alt={servicesData[selectedService].title}
              className="banner-logo"
            />
            <h3>{servicesData[selectedService].title}</h3>
            <p>{servicesData[selectedService].details}</p>
          </div>
        </div>
      )}
    </div>
       <Footer />
    </>
  );
};

export default Services;

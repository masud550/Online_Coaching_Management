// ========================= Main App =========================
import React, { useState, useEffect } from 'react';
import Loader from './components/Loader'; 
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// ========================= Components =========================
import Home from './components/Home';
import Contact from './components/Contact';
import Courses from './components/Courses';
import RegisterWithCode from "./components/RegisterWithCode";
import StudentDashboard from "./components/StudentDashboard";
import CourseVideos from "./components/CourseVideos";
import Login from "./components/Login";   
import TeacherDashboard from './components/Dashboard/TeacherDashboard';
import InstitutionDashboard from './components/Dashboard/InstitutionDashboard';
import Expertise from './components/Expertise';
import Gallery from './components/Gallery';
import Navbar from './components/Navbar';
import SuccessStory from './components/SuccessStory';
import Media from './components/Media';
import OurServices from './components/OurServices'; 
import Events from './components/Events';
import CourseDetail from './components/CourseDetail';
import ExpertDetail from "./components/ExpertDetail";
function App() {
  const [loading, setLoading] = useState(true);

  // ========================= Loader Timeout =========================
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <Loader />;
  }

  // ========================= Router =========================
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/expertise" element={<Expertise />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/login" element={<Login />} />
        <Route path="/successstory" element={<SuccessStory />} />
        <Route path="/media" element={<Media />} />
        <Route path="/events" element={<Events />} />
        <Route path="/ourservices" element={<OurServices />} /> 
        <Route path="/newsletter" element={<div>Newsletter Page</div>} />
        <Route path="/about" element={<div>About Page</div>} />
        <Route path="/mentors" element={<div>Mentors Page</div>} />
        <Route path="/dashboard/teacher" element={<TeacherDashboard />} />
        <Route path="/dashboard/institution" element={<InstitutionDashboard />} />
        <Route path="/register-with-code" element={<RegisterWithCode />} />
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        <Route path="/course/:id/videos" element={<CourseVideos />} />
        <Route path="/courses/:id" element={<CourseDetail />} />
        <Route path="/expert/:id" element={<ExpertDetail />} />
      </Routes>
    </Router>
  );
}

export default App;

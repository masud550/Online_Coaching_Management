// api/enrollmentApi.js
import axios from "axios";

const API_BASE = process.env.REACT_APP_API_BASE_URL;

export const enrollCourse = async (courseId, token) => {
  return await axios.post(
    `${API_BASE}/api/enroll/`,
    { course: courseId },
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
};

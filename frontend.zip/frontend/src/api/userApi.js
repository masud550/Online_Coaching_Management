// src/api/userApi.js
const API_BASE = process.env.REACT_APP_API_BASE_URL;

export const registerUser = async (userData) => {
  // Map frontend "roleExtra" -> user_id if role === student
  const payload = { ...userData };
  if (payload.role === 'student' && payload.roll_number) {
    payload.student_id = payload.roll_number;
    delete payload.roll_number;
  }
  const res = await fetch(`${API_BASE}/register/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error ? JSON.stringify(data.error) : 'Registration failed');
  return data;
};

export const loginUser = async (credentials) => {
  const res = await fetch(`${API_BASE}/login/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Login failed');
  return data;
};

export const getMe = async (token) => {
  if (!token) throw new Error('No token provided');

  const res = await fetch(`${API_BASE}/me/`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.detail || 'Failed to fetch profile');
  return data;
};

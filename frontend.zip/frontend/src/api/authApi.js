//C:\Projects\online_coaching_management\frontend\src\api\authApi.js
export const saveTokens = (access, refresh, remember = false) => {
  const storage = remember ? localStorage : sessionStorage;
  storage.setItem('token', access);
  if (refresh) storage.setItem('refreshToken', refresh);
};

export const getToken = () =>
  localStorage.getItem('token') || sessionStorage.getItem('token');

export const clearTokens = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('refreshToken');
  sessionStorage.removeItem('token');
  sessionStorage.removeItem('refreshToken');
};

// src/api/courseApi.js
import axios from "axios";
import { getToken } from "./authApi";

// Base API instance
const api = axios.create({
  baseURL: "http://127.0.0.1:8000/api/", 
});

// Add token automatically
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ✅ Fetch all courses
export const fetchCourses = async () => {
  try {
    const response = await api.get("courses/"); // <-- backend endpoint must exist
    return response.data;
  } catch (error) {
    console.error("Error fetching courses:", error);
    throw error;
  }
};

// ✅ Fetch a single course by ID
export const fetchCourseById = async (id) => {
  try {
    const response = await api.get(`courses/${id}/`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching course ${id}:`, error);
    throw error;
  }
};

// ✅ Create a new course (for teachers/admins)
export const createCourse = async (courseData) => {
  try {
    const response = await api.post("courses/", courseData);
    return response.data;
  } catch (error) {
    console.error("Error creating course:", error);
    throw error;
  }
};

// ✅ Update a course
export const updateCourse = async (id, courseData) => {
  try {
    const response = await api.put(`courses/${id}/`, courseData);
    return response.data;
  } catch (error) {
    console.error(`Error updating course ${id}:`, error);
    throw error;
  }
};

// ✅ Delete a course
export const deleteCourse = async (id) => {
  try {
    await api.delete(`courses/${id}/`);
    return true;
  } catch (error) {
    console.error(`Error deleting course ${id}:`, error);
    throw error;
  }
};

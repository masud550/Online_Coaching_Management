// src/api/backend.js

export async function fetchBackendMessage() {
  const response = await fetch('http://127.0.0.1:8000/api/'); // or your actual endpoint
  const data = await response.json();
  return data;
}
